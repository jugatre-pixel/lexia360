from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from core.config import settings
from core.db import engine
from sqlmodel import SQLModel

from routers.auth import router as auth_router
from routers.inmuebles import router as inmuebles_router
from routers.zonas import router as zonas_router
from routers.documents import router as documents_router

def create_app() -> FastAPI:
    app = FastAPI(title=settings.app_name, version=settings.app_version)

    # CORS (ajusta ORIGINS en producción)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Static UI
    app.mount("/static", StaticFiles(directory="static"), name="static")

    @app.on_event("startup")
    def on_startup() -> None:
        # Crea tablas si no existen (para MVP). Para prod, usa Alembic.
        SQLModel.metadata.create_all(engine)

    # Routers API
    app.include_router(auth_router, tags=["auth"])
    app.include_router(inmuebles_router)
    app.include_router(zonas_router)
    app.include_router(documents_router)

    @app.get("/health")
    def health():
        return {"status": "ok", "app": settings.app_name, "version": settings.app_version}

    return app

app = create_app()
